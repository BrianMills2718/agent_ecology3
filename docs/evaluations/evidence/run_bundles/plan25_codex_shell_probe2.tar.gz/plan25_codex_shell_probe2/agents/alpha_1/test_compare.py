def compare_one(a, b):
    def numeric(x):
        if isinstance(x, str):
            return float(x.replace(',', '.'))
        return float(x)
    av, bv = numeric(a), numeric(b)
    if av == bv:
        return None
    return a if av > bv else b

assert compare_one(1, 2.5) == 2.5
assert compare_one(1, '2,3') == '2,3'
assert compare_one('5,1', '6') == '6'
assert compare_one('1', 1) is None
assert compare_one('2,5', 2) == '2,5'
