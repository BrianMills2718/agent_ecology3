def numerical_letter_grade(grades):
    out = []
    for g in grades:
        if g == 4.0: out.append('A+')
        elif g > 3.7: out.append('A')
        elif g > 3.3: out.append('A-')
        elif g > 3.0: out.append('B+')
        elif g > 2.7: out.append('B')
        elif g > 2.3: out.append('B-')
        elif g > 2.0: out.append('C+')
        elif g > 1.7: out.append('C')
        elif g > 1.3: out.append('C-')
        elif g > 1.0: out.append('D+')
        elif g > 0.7: out.append('D')
        elif g > 0.0: out.append('D-')
        else: out.append('E')
    return out

assert numerical_letter_grade([4.0, 3, 1.7, 2, 3.5]) == ['A+', 'B', 'C-', 'C', 'A-']
assert numerical_letter_grade([3.7, 3.3, 3.0, 2.7, 2.3, 2.0, 1.3, 1.0, .7, 0]) == ['A-', 'B+', 'B', 'B-', 'C+', 'C', 'D+', 'D', 'D-', 'E']
